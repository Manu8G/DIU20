/*******************************************/
/*             PERSONA.JS                  */
/*     Datos para PERSONA TEMPLATE         */   
/*          [DIU] UX Toolkit               */                        
/*          ver 1.0, 2019                  */
/*******************************************/
    
/****  README:       */
/****  Modifica los datos para las Personas      */
/****  Las imagenes para  'Photo'  están en carpeta ./photos **/
/****  Si se usan nuevas imágenes se deben añadir a esa carpeta **/
/****  Los valores de rating están entre 1..5 **/
/****  recursos de imágenes:  https://www.vectorstock.com/royalty-free-vectors/vectors-by_zdeneksasek ***/



angular.module("angular", [])
	.controller("controller", ["$scope", function($scope) { 
		
		$scope.PersonaIndex = 0;
		$scope.Personas = [
			{		
                
                /*************************************/
                /**** PRIMERA PERSONA          *******/
                /*** Cambiar datos             *******/
                /*************************************/
                
                
				Id: 0,
				Name: "María Montes De Oca Lorca ",
				Photo: "woman.png",
				Quote: "Disfruta de los pequeños momentos",
				Age: 37,
				Occupation: "Dueña de una cafetería",
				Family: "Casada y con una hija",
				Location: "Malaga (Estepona)",
				Character: "Su familia y el deporte",
				PersonalityTraits: [
					{ Name: "Introvertido/reservado Vs  Extrov/activo ", Value: 5 },
					{ Name: "Realista/práctico  Vs    Intuición/imaginativo", Value: 5 },
					{ Name: "Racional/analitico  Vs   Emocional/impulsivo", Value: 2 },
					{ Name: "Flemático/apático  Vs   Colérico/visceral", Value: 2 }
				], 
				Goals: ["Le gustaria abrir otra cafeteria, puesto que le va bastante bien, pero necesita encontrar a alguien de confianza para que le ayude"],
				Frustrations: ["No se lleva muy bien con la tecnologia, su hija sabe mas que ella y le tiene que ayudar en casi todo", "Le gustaría montar un club de ciclismo activo pero sus actuales compañeros no tienen horarios fijos por lo que le es muy dificil"],
				Bio: "Es de Ronda y se mudo a Estepona cuando se caso con su marido con el que empezo a trabajar en una cafeteria que montaron. LLevan ya 7 años con la cafeteria y les va muy bien. Ha hecho buenos amigos con los que hace ciclismo y escalada",
				Tech: [
					{ Name: "TIC/Internet", Value: 1 },
					{ Name: "Movil", Value: 5 },
					{ Name: "RRSS", Value: 4 },
					{ Name: "Software", Value: 1 }
					
				], 
                Contextos: "Le gustaria tomar ideas de otros lugares para su nueva cafeteria asi que quiere viajar a otra parte y recorrer muchos pueblos y ciudades para recopilar ideas",  
				PreferredChannels: [
					{ Name: "Publicidad Tradicional", Value: 5 },
					{ Name: "Online & Social Media", Value: 2 },
					{ Name: "Recomendaciones & sugerencias", Value: 3 },
					{ Name: "Persona confianza (amigos, boca a boca)", Value: 5 }
				]
			},
			{	
                
                /*************************************/
                /**** SEGUNDA PERSONA          *******/
                /*** Cambiar datos             *******/
                /*************************************/
                
                
				Id: 1,
				Name: "Jesús Garrido Camacho",
				Photo: "man.png",
				Quote: "Tempus fugit",
				Age: 19,
				Occupation: "Cajero en un supermercado",
				Family: "Muy familiar, vive con sus padres",
				Location: "Valencia (Valencia)",
				Character: "No hay que perder el tiempo hay que aprovechar cada segundo",
				PersonalityTraits: [
					{ Name: "Introvertido/reservado Vs  Extrov/activo ", Value: 4 },
					{ Name: "Realista/práctico  Vs    Intuición/imaginativo", Value: 5 },
					{ Name: "Racional/analitico  Vs   Emocional/impulsivo", Value: 3 },
					{ Name: "Flemático/apático  Vs   Colérico/visceral", Value: 4 }
				], 
				Goals: ["Afianzarse en su empresa puesto que le gusta su trabajo ya que no es muy complicado y suele caerle muy bien a la gente.", "Le gustaria que le tocase la bonoloto para poder comprarse un piso para alquilarlo y ganar dinero facil.", "Quiere pedirle salir a ''La Patri''.","Quiere ir a ver la SuperBowl"],
				Frustrations: ["No tener suficiente dinero para poder vivir sin trabajar.", "No le gusta el hecho de no poder cuadrar horarios con sus amigos para quedar.", "Le preocupa la salud de su padre.", "No le cae bien la madre de ''La Patri''."],
				Bio: "De pequeño vivio en Badalona, pero debido a la salud de su padre se vieron obligados a mudarse a Valencia, cuando el tenia 5 años, para poder estar cerca de su tio que era medico. No le gustaba estudiar asi que dejo el instituto en cuanto termino la E.S.O. despues empezo a trabajar en un supermercado en el que se siente muy agusto y donde conocio al amor de su vida ''La Patri''. Le gusta mucho el futbol americano, siempre ve los partidos online y este año quiere ir a ver la final de la SuperBowl",
				Tech: [
					{ Name: "TIC/Internet", Value: 4 },
					{ Name: "Mobile", Value: 5 },
					{ Name: "RRSS", Value: 5 },
					{ Name: "Software", Value: 4 }
					
				], 
                Contextos:   "Le gustaria ir a ver la SuperBowl pero no quiere pagar mucho y tampoco quiere ir solo." ,
				PreferredChannels: [
					{ Name: "Publicidad Tradicional (Ads)", Value: 3 },
					{ Name: "Online & Social Media", Value: 5 },
					{ Name: "Recomendaciones & sugerencias", Value: 5 },
					{ Name: "Persona confianza (amigos, boca a boca)", Value: 5 }
				]
			}
		];
		$scope.model = $scope.Personas[0];

	}])