/*******************************************/
/*             JOURNEY.JS                  */
/*     Datos para USER JOURNEY MAP         */   
/*          [DIU] UX Toolkit               */                        
/*          ver 1.0, 2019                  */
/*******************************************/
    
/****  README:       */
/****  Modifica los datos para los Journey Map (uno para cada Persona)  */
/****  Usa los 6 pasos y sigue las instrucciones */   
/****  Las imagenes para  'Photo', 'feelX', 'imaX' están en carpeta ./photos **/
/****  Si se usan nuevas imágenes se deben añadir a esa carpeta **/
/****  Los valores de rating están entre 1..5 **/
/****  recursos de imágenes:  https://www.vectorstock.com/royalty-free-vectors/vectors-by_zdeneksasek ***/




angular.module("angular", [])
	.controller("controller", ["$scope", function($scope) { 
		
		$scope.JourneyIndex = 0;
        
        $scope.Journeys = [
			{		
                
                /*************************************/
                /**** PRIMER USER JOURNEY MAP  *******/
                /*** Cambiar datos             *******/
                /*************************************/
                
				Id: 0,
				Name: "Jesús Garrido",
                Photo: "man.png",
    
                /*** PASO #1: INSPIRACION ***/ 
                goal1: "Quiere ir a ver la final de la SuperBowl",
                touch1: "Ordenador",
                feel1: "5",
                con1: "Va a ser su primer viaje en solitario",
                ima1: "cartoon-deciding.png",
				
                /*** PASO #2: DECICION ***/ 
                goal2: "Busca ofertas y desconocidos con los que viajar",
                touch2: "ordenador",
                feel2: "3",
                con2: "Hay demasiada información y pierde mucho tiempo, todo es muy caro",
                ima2: "cartoon-PCangry.png",
                
                /*** PASO #3: ACTUA ***/ 
                
                goal3: "Decide alquilar una casa en las afueras y un coche",
                touch3: "móvil y ordenador",
                feel3: "1",
                con3: "Está preocupado por el aparcamiento y por si la gente no se apuntara a su viaje, puesto que le saldria muy caro",
                ima3: "cartoon-PCcrying.png",
                
                /*** PASO #4: OBSERVA ***/ 
                
                goal4: "Busca casas en las afueras y pregunta en inmobiliarias de la ciudad",
                touch4: "ordenador",
                feel4: "2",
                con4: "Todo lo barato esta cogido solo queda lo caro",
                ima4: "cartoon-PCangry.png",
                
                 /*** PASO #5: ANALIZA ***/ 
                
                goal5: "En cuentra una casa a 45 minutos de distancia y un coche de alquiler pequeño",
                touch5: "móvil (whatsapp)",
                feel5: "4",
                con5: "Solo le queda que la gente se apunte a su viaje",
                ima5: "cartoon-phoning.png",
                
                
                /*** PASO #6: CONCLUSION ***/ 
                
                goal6: "Se acaban uniendo 2 personas mas",
                touch6: "ordenador",
                feel6: "4",
                con6: "Lo perfecto hubiera sido que se le unieran 3 personas pero es mejor que ir solo",
                ima6: "cartoon-speaking.png",
                
			},
			{	
                /*************************************/
                /**** SEGUNDO USER JOURNEY MAP *******/
                /***      Cambiar datos        *******/
                /*************************************/
                
				Id: 1,
				Name: "Maria Montes",
                Photo: "woman.png",
                
				 /*** PASO #1: INSPIRACION ***/ 
                goal1: "Quiere preparar un viaje familiar para relajarse antes de emprender su nueva etapa",
                touch1: "Agenda",
                feel1: "5",
                con1: "Quiere visitar muchas ciudades y cafeterias para inspirarse",
                ima1: "cartoon-going.png",
                
                /*** PASO #2: DECICION ***/ 
                goal2: "Un amigo le recomienda consultar una pagina web a ver que viajes ofertan",
                touch2: "Ordenador",
                feel2: "1",
                con2: "No se lleva bien con la tecnologia, si la sacas del whatsapp se pierde. Le pide muchos datos y le resulta incómodo completar formulario",
                ima2: "cartoon-PCangry.png",
                
                /*** PASO #3: ACTUA ***/ 
                
                goal3: "Encuentra un viaje en autocaravana ofertado por una profesora de un pueblo vecino",
                touch3: "Móvil (llamada)",
                feel3: "3",
                con3: "Piensa que ha tenido bastante suerte al encontrarla pero no le gusta la idea de la autocaravana",
                ima3: "cartoon-phoningangry.png",
                
                /*** PASO #4: OBSERVA ***/ 
                
                goal4: "Discute un poco el viaje con la mujer que lo oferta",
                touch4: "Móvil (whatsapp)",
                feel4: "2",
                con4: "Le cuesta mucho convencerla de visitar diversos lugares",
                ima4: "cartoon-talking.png",
                
                 /*** PASO #5: ANALIZA ***/ 
                
                goal5: "Reserva a traves de la aplicación",
                touch5: "Ordenador",
                feel5: "2",
                con5: "Al final consigue un punto medio con la mujer y se acaba decantando por apuntarse con su familia",
                ima5: "cartoon-deciding.png",

                
                /*** PASO #6: CONCLUSION ***/ 
                
                goal6: "El viaje fue desastroso acabo muy agoviada con la autocaravana pero consiguio muchos datos para su nueva cafeteria asi que esta contenta",
                touch6: "Ordenador (reserva OK)",
                feel6: "3",
                con6: "Tendra que contratar un viaje en condiciones, esta vez de una agencia profesional de las que vio en la pagina web, para relajarse de verdad",
                ima6: "cartoon-phone-sitting.png",
                
                
                
			}
		];
        
		$scope.model = $scope.Journeys[0];

	}])
